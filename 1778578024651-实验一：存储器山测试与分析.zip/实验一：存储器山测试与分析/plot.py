import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 1. 读取清洗后的矩阵数据
try:
    # mountain_clean.txt 与 plot.py 需在同一目录执行
    Z = np.loadtxt('mountain_clean.txt')
except Exception as e:
    print(f"读取文件失败，请确保 mountain_clean.txt 与脚本在同一目录。错误: {e}")
    exit()

# 只保留前 13 行（128MB 到 32KB）
### 更改过size范围需相应更改数据，eg: 32MB：13 改为 11
Z = Z[:13, :]

# 2. 构建坐标网格
# Y 轴范围对应 128M (2^27) 到 32K (2^15)
### 更改过size范围需相应更改数据，eg: 32MB：27 改为 25
size_log_vals = np.arange(27, 14, -1)
stride_vals = np.arange(1, 65)

# 生成网格
X, Y = np.meshgrid(stride_vals, size_log_vals)

# 3. 噪声处理
Q99 = np.percentile(Z, 99)
Z[Z > Q99 * 1.5] = Q99 * 1.5

# 4. 画图
fig = plt.figure(figsize=(14, 10))
ax = fig.add_subplot(111, projection='3d')
surf = ax.plot_surface(X, Y, Z, cmap='turbo', edgecolor='black', linewidth=0.1, alpha=0.9)

ax.set_title('The Memory Mountain', fontsize=20, fontweight='bold', pad=20)


# X 轴 (Stride)
x_ticks = np.array([1, 8, 16, 24, 32, 40, 48, 56, 64])
ax.set_xticks(x_ticks)
ax.set_xticklabels([f's{x}' for x in x_ticks])
ax.set_xlabel('Stride (x8 bytes)', fontsize=12, labelpad=10)

# Y 轴 (Size)
def format_size(log_val):
    size = 2 ** log_val
    if size >= 1024 * 1024:
        return f'{int(size / (1024 * 1024))}m'
    else:
        return f'{int(size / 1024)}k'

y_ticks = np.unique(size_log_vals)
ax.set_yticks(y_ticks[::2])  # 每隔一个刻度显示一次
ax.set_yticklabels([format_size(v) for v in y_ticks[::2]])
ax.set_ylabel('Size (Bytes)', fontsize=12, labelpad=15)

ax.set_zlabel('Read Throughput (MB/s)', fontsize=12, labelpad=15)

# 视角
ax.view_init(elev=35, azim=45)

# 颜色条
fig.colorbar(surf, shrink=0.5, aspect=12, pad=0.1, label='Throughput (MB/s)')

# 在右上角添加 CPU 硬件信息
cpu_info_text = (
    "CPU: Intel(R) Core(TM) i7-14650HX \n"
    "CPU Frequency: 2.4 GHz\n"
    "L1 d-cache: 48 KB\n"
    "L2 cache: 2 MB\n"
    "L3 cache: 30 MB\n"
    "Block size: 64 B"
)

# 在 3D 坐标系的右上角绘制文本框
ax.text2D(1, 1, cpu_info_text,
          transform=ax.transAxes,      # 使用轴坐标系 (0~1)
          fontsize=12,                 # 字体大小
          fontweight='bold',           # 字体加粗
          color='black',
          ha='left', va='top',        # 右对齐，顶部对齐
          bbox=dict(boxstyle='round,pad=0.5', facecolor='white', alpha=0.85, edgecolor='gray')) # 半透明白色背景框

plt.savefig('参考图片.png', dpi=300, bbox_inches='tight')
print("图片已生成：参考图片.png")
plt.show()