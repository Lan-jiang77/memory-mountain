说明：mountain为官方测试代码。由于官方提供的测试代码仅适配linux的x86系统，故windows系统推荐采用wsl进行测试（不强制要求采用此方式，可使用其他环境或根据个人电脑自行修改代码）



##### 以下实现均仅供参考，需根据具体情况调整


### 根据自己的电脑配置修改 mountain 测试代码
##### 1.安装wsl
# wsl安装可参考：https://blog.csdn.net/qq_32699011/article/details/155914942
补充说明：win11系统安装wsl时，可不用dism命令，直接运行wsl --install，失败则根据教程操作。


##### 2.wsl使用
### （1）在终端中启动wsl
wsl
### （2）安装 C 语言全家桶 (编译代码用)
# 下载极慢或失败，参考上述教程链接的更换镜像源操作
sudo apt update
sudo apt install build-essential
### （3）进入项目目录
cd "/mnt/d/……/mountain"
### （4）编译
make clean
make
### （5）运行测试并捕获数据
./mountain > mountain.data
### （6）数据清洗（去掉文字干扰，保留纯数字矩阵）
awk 'NR>3 {$1=""; print $0}' mountain.data > mountain_clean.txt


##### 3.画图（脚本供参考，可自行挑战）
### 清洗后的.txt矩阵数据可采用plot.py脚本生成图片
# 更改过size范围，需相应修改脚本内的 Z = Z[:13, :] 以及 size_log_vals = np.arange(27, 14, -1)